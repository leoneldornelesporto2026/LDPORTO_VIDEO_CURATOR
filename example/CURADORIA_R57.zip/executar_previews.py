#!/usr/bin/env python3
"""Renderiza previews verificáveis da curadoria R57.

Não publica, não aprova, não queima automaticamente o ASR não revisado.
Para render final, exige registro explícito de aprovação por arquivo de preview e SHA256.
Requer Python 3.10+, ffmpeg e ffprobe instalados no PATH.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from uuid import uuid4

HERE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()

def verify_tools():
    for name in ('ffmpeg','ffprobe'):
        if not shutil.which(name):raise RuntimeError(name+' indisponível no PATH.')

def probe(path):
    return json.loads(subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)],check=True,text=True,capture_output=True).stdout)

def render(original,clip,path,quality):
    if path.exists():raise FileExistsError(f'Arquivo pré-existente preservado: {path}')
    path.parent.mkdir(parents=True,exist_ok=True)
    w,h=(540,960) if quality=='preview' else (1080,1920)
    start=float(clip['source_start']);dur=float(clip['duration_seconds'])
    # Keep the *entire* 16:9 stage inside a vertical canvas; no speculative face crop.
    # This is a conservative editorial preview. Lens choices from the Analyzer still need human review.
    vf=(f'[0:v]split=2[bg][fg];'
        f'[bg]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},'
        f'boxblur=luma_radius=30:luma_power=1,eq=brightness=-0.13[blur];'
        f'[fg]scale={w}:-2:flags=lanczos[front];'
        f'[blur][front]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p[v]')
    temp=path.with_name('.working_'+uuid4().hex+'_'+path.name)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-n','-ss',f'{start:.3f}','-i',str(original),'-t',f'{dur:.3f}','-filter_complex',vf,
         '-map','[v]','-map','0:a:0?','-r','30','-c:v','libx264','-preset','veryfast' if quality=='preview' else 'medium',
         '-crf','24' if quality=='preview' else '19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k' if quality=='preview' else '192k',
         '-ar','48000','-movflags','+faststart',str(temp)]
    try:
        subprocess.run(cmd,check=True)
        actual=probe(temp)
        vs=[s for s in actual.get('streams',[]) if s.get('codec_type')=='video']
        aud=[s for s in actual.get('streams',[]) if s.get('codec_type')=='audio']
        observed=float(actual.get('format',{}).get('duration') or 0.)
        if not vs or int(vs[0].get('width',0))!=w or int(vs[0].get('height',0))!=h:
            raise RuntimeError('Preview não tem resolução/stream de vídeo esperado.')
        if not aud:raise RuntimeError('O preview não contém áudio: origem deve ter áudio.')
        if abs(observed-dur)>1.0:raise RuntimeError(f'Duração diferente do plano: esperado={dur} observado={observed}.')
        os.link(temp,path)  # Nunca sobrescrever outros arquivos, inclusive em concorrência.
        temp.unlink(missing_ok=True)
        return {'path':str(path),'sha256':sha(path),'duration_seconds':observed,'codec':vs[0].get('codec_name'),'audio_present':True,
                'subtitle_overlay':'OFF_ASR_NOT_REVIEWED','visual_layout':'16:9_SOURCE_PRESERVED_ON_9:16_BLUR','approved':False}
    except Exception:
        # Keep interrupted evidence for inspection instead of touching old files.
        raise RuntimeError('Render/validação falhou; tentativa preservada em: '+str(temp))

def main():
    ap=argparse.ArgumentParser(description='Render de prévias da segunda curadoria CBJR — sem publicação automática.')
    ap.add_argument('--original',required=True,help='MP4/MKV original com o mesmo SHA256 da fonte analisada.')
    ap.add_argument('--kind',choices=['reels','stories','all'],default='reels')
    ap.add_argument('--limit',type=int,default=1,help='Quantidade máxima por tipo (0 = todas).')
    ap.add_argument('--output',default=str(HERE/'RESULTADOS_LOCAIS'))
    ap.add_argument('--final',action='store_true',help='Só renderiza cortes aprovados por hash no arquivo APROVACAO_PREVIAS.json.')
    args=ap.parse_args()
    verify_tools()
    original=Path(args.original).expanduser().resolve()
    if not original.is_file():raise FileNotFoundError(original)
    plan=json.loads((HERE/'EXECUTION_PLAN.json').read_text(encoding='utf-8'))
    digest=sha(original)
    if digest!=plan['source_sha256']:
        raise ValueError('Fonte divergente. SHA256 do vídeo não corresponde à análise; não usar outro download sem nova análise.')
    d=probe(original)
    if not any(s.get('codec_type')=='audio' for s in d.get('streams',[])):
        raise RuntimeError('Mídia original sem áudio; não é possível produzir cortes fiéis.')
    observed=float(d.get('format',{}).get('duration') or 0)
    if abs(observed-plan['source_duration_seconds'])>0.65:
        raise RuntimeError('Duração do vídeo não confere com o contrato da análise.')
    output=Path(args.output).expanduser().resolve()
    if args.final:
        approvals_file=HERE/'APROVACAO_PREVIAS.json'
        if not approvals_file.is_file():raise RuntimeError('Faltou APROVACAO_PREVIAS.json assinado manualmente com SHA256 do preview aprovado.')
        approvals=json.loads(approvals_file.read_text(encoding='utf-8'))
        if approvals.get('source_sha256')!=digest:raise RuntimeError('Aprovações referem-se a outra mídia.')
    else: approvals={}
    manifest={'source_sha256':digest,'mode':'FINAL_AFTER_APPROVAL' if args.final else 'REVIEW_ONLY_PREVIEW','results':[]}
    for kind in (['reels','stories'] if args.kind=='all' else [args.kind]):
        rows=plan[kind]
        if args.limit>0:rows=rows[:args.limit]
        for clip in rows:
            name=clip['id']
            if args.final:
                approval=approvals.get('approved',{}).get(name,{})
                prior=output/'PREVIEWS'/kind/(name+'.mp4')
                if approval.get('approved') is not True or not prior.is_file() or sha(prior)!=approval.get('preview_sha256'):
                    raise RuntimeError(f'Faltou aprovação válida por SHA256 do preview para {name}.')
            target=output/('FINAIS' if args.final else 'PREVIEWS')/kind/(name+'.mp4')
            print('Renderizando',name,clip['source_start'],clip['source_end'],'->',target,flush=True)
            result=render(original,clip,target,'final' if args.final else 'preview')
            manifest['results'].append({'id':name,**result})
            # Persist successful results incrementally; failed output never marked complete.
            report=output/'EVIDENCIA_RENDERS.json'
            report.parent.mkdir(parents=True,exist_ok=True)
            report.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Concluído. Artefatos NÃO aprovados/publicados; revisar pessoalmente os MP4s.')

if __name__=='__main__':
    try: main()
    except (ValueError,RuntimeError,FileNotFoundError,subprocess.CalledProcessError) as exc:
        print('BLOQUEADO:',exc,file=sys.stderr)
        sys.exit(2)
