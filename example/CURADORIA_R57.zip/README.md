# L.D.PORTO — SEGUNDA CURADORIA / PLANETA ATLÂNTIDA 2012

**Estado: MATERIAL DE TRABALHO PARA REVISÃO E EXECUÇÃO LOCAL — NÃO APROVADO PARA PUBLICAÇÃO.**

Fonte: Charlie Brown Jr - Planeta Atlântida 2012 (Completo) HD (3591.194s / 59:51.194); SHA256 f8b424b9fc26c79141fb2288fee3354d5f02c1c773523f87f95b1191252283ea
Arquivo de análise recebido: SECOND_CURATION_PARTIAL_aUgESZsOGmY_20261020_021726_604899_b780c1.zip — SHA256 `7dc84cf4f257578376c5aafb648139168cb94154475493222be8a22ef9605363`.

**Entregas:** 12 propostas de Reels + 60 Stories cronológicos contínuos; 72 capas PNG de referência, SRT e ASS rascunho para cada peça, descrição/tags por peça.

## Reels propostos

| Nº | Entrada | Saída | Duração | Título / gancho | Principal pendência |
|---:|---:|---:|---:|---|---|
| 01 | 1869.29s | 1884.14s | 14.85s | 20 ANOS DE BANDA | ALIGNMENT_REVIEW_REQUIRED |
| 02 | 1459.54s | 1490.15s | 30.61s | O SUL É NOSSA CASA | context_gap_requires_review; ALIGNMENT_REVIEW_REQUIRED |
| 03 | 2355.13s | 2429.63s | 74.50s | VOCÊS SÃO A FAMÍLIA | context_gap_requires_review; ALIGNMENT_REVIEW_REQUIRED |
| 04 | 2152.16s | 2199.40s | 47.24s | A GALERA ENTROU NA ONDA | context_gap_requires_review; topic_boundary_crossed |
| 05 | 500.02s | 511.98s | 11.96s | ELA SORRIU PRA MIM | ALIGNMENT_REVIEW_REQUIRED |
| 06 | 1853.21s | 1868.91s | 15.70s | QUE NOITE INESQUECÍVEL | mid_sentence; ALIGNMENT_REVIEW_REQUIRED |
| 07 | 3196.52s | 3205.40s | 8.88s | O FUTURO É VOCÊS | missing_antecedent_or_continuation; topic_boundary_crossed |
| 08 | 3510.35s | 3555.76s | 45.41s | VOCÊS FAZEM PARTE | answer_or_payoff_unresolved; incomplete_sentence_or_handoff |
| 09 | 2627.06s | 2671.69s | 44.63s | NÃO TEM PREÇO | answer_or_payoff_unresolved; context_gap_requires_review |
| 10 | 1679.90s | 1730.10s | 50.20s | QUEM VAI TE FAZER FELIZ? | context_gap_requires_review; incomplete_sentence_or_handoff |
| 11 | 1131.58s | 1192.12s | 60.54s | EU NÃO TE IMAGINEI ASSIM | answer_or_payoff_unresolved; context_gap_requires_review |
| 12 | 3141.42s | 3157.75s | 16.33s | UMA BANDA DE RESPEITO | incomplete_sentence_or_handoff; COMMERCIAL_REVIEW_PENDING |

## Stories — show integral (R5.6)

60 partes em ordem, de 00:00:00.000 a 00:59:51.194. Partes 01–59 com 60 segundos; parte 60 com 51,194 segundos. **Sem remover nenhum intervalo nem remontar discursos.** A fronteira de minuto ainda pode interromper palavra ou música; portanto a aprovação da execução depende de escutar os 59 pontos de corte.

## Padrão editorial recuperado

- Formato de prévia **540×960** e final **1080×1920** (9:16). Capas entregues em **1080×1920 PNG** com fonte apenas de contact sheets (amostras de baixa resolução); refazer as capas definitivas do MP4 validado.
- Identidade visual: **caixa branca, letra preta, etiqueta amarela, marca @L.D.PORTO.OFICIAL**, gancho curto, sem atribuir declarações inexistentes.
- Legendas: arquivos **SRT** e **ASS amarelo→branco** extraídos do ASR original, **não revisados por escuta**. O executor não os queima automaticamente.
- Câmera: primeiro **SOURCE_PRESERVE** (16:9 dentro da tela vertical com blur); crop em rosto/corpo somente quando tracking e vídeo verificados, não inventar pessoa ativa.
- Áudio: original contínuo para Stories; em Reels manter continuidade das falas e músicas; sem fade/efeito sem escuta.
- Metadados de publicação em cada pasta: título, texto, CTA, comentário fixado, hashtags e tags sob 500 caracteres.

## Limitações verificadas

- O ZIP de análise **não contém MP4 nem trilha original de áudio**. Nenhum corte ou story foi renderizado neste ambiente.
- Analyzer marcou **69 candidatos, shortlist oficial 0**, transcrição de aproximadamente **27,56%** e **54 candidatos exigindo revisão comercial**.
- Preflight de legendas: **68 ALIGNMENT_REVIEW_REQUIRED** e **1 AUDIO_REVIEW_REQUIRED**; nenhuma escuta de validação foi realizada.
- Só há frames esparsos de contact sheets; **não é possível validar suavidade da câmera nem o frame real da capa**.
- Nada foi aprovado automaticamente; verificação técnica de ZIP e dados não equivale a aprovação humana.

## Importar para Video Curator V4.4 + motor local

1. No Curator, importar primeiro o arquivo original `SECOND_CURATION_PARTIAL_...zip` (manter os seis PDFs de atlas; o importador precisa dar suporte a eles).
2. Importar `SECOND_CURATION_DECISIONS.json` **deste pacote**. As ações são `promote` e não `approve`; a GUI deve sinalizar REVISÃO PENDENTE.
3. O arquivo `STORIES_SEQUENCIAIS_REVISAR.json` é um contrato complementar planejado para a sequência de Stories; a UI/versão local pode exigir um adaptador para consumi-lo.
4. Para teste independente com FFmpeg, executar `py executar_previews.py --original "C:\caminho\aUgESZsOGmY.mp4" --kind reels --limit 1` a partir da pasta extraída.
5. Escutar, corrigir legendas, ajustar câmera/cortes, aprovar hash da prévia; só depois renderizar finais e publicar, com direitos liberados.

## Mapa de arquivos

- `SECOND_CURATION_DECISIONS.json`: contrato oficial importável no motor V4.4.
- `REELS_EDIT_PLAN.json`, `REELS_TIMELINE.csv`: direção editorial e riscos.
- `STORIES_SEQUENCIAIS_REVISAR.json`, `STORIES_TIMELINE.csv`: cobertura integral do show.
- `REELS/REEL_NN/` e `STORIES/STORY_NN/`: capa PNG + SRT/ASS RASCUNHO + JSON de publicação.
- `QUALITY_GATES.json`: status e bloqueios.
- `CATALOGO_COMPLETO_69_PARA_REAVALIAR.json`: todos os candidatos preservados para o segundo editor.
- `EXECUTION_PLAN.json`, `executar_previews.py`: renderizador de **prévia conservadora**, exige SHA256 do original.

## Importante

Os títulos são **propostas editoriais** baseadas em transcrição/categorias, não falas certificadas. Não usar thumbnails e legendas do ZIP como se fossem arquivos finais sem reextrair imagens da mídia verificada e ouvir o áudio.
